#!/bin/bash
cd KrA
./code.sh
