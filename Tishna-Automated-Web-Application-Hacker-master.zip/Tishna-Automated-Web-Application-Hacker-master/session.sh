#!/bin/bash
echo -e "[!] This tutorial is requires burp suite"
echo -e "[~] https://resources.infosecinstitute.com/burps-session-handling-mechanisms/"