#!/bin/bash
cd oxml_xxe/docker/docker-oxml_xxe
echo -e "Executing, wait and visit : http://127.0.0.1:4567 "
./run.sh
