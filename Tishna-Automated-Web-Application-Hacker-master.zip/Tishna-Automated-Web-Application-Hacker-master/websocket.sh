#!/bin/bash
cd websocket
./websocket_first.sh
./websocket_second.sh
