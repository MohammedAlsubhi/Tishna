# Tishna
 Complete Automated pentest framework for Servers, Application Layer to Web Security

# LICENSE
EULA

# Interface
- Software have 62 Options with full automation and can be use for web security swiss knife
<div align="center">
    <img src="https://i.ibb.co/VmzRBC3/t1.png" width="400px"</img> 
</div>

<div align="center">
    <img src="https://i.ibb.co/28ZbpM1/t12.png" width="400px"</img> 
</div>

<div align="center">
    <img src="https://i.ibb.co/5kSZYJ2/t3.png" width="400px"</img> 
</div>

# Tishna
- Tishna is Web Server Security Penetration Software for Ultimate Security Analaysis
- Kali, Parrot OS, Black Arch, Termux, Android Led TV

# Appeared
- Cyber Space (Computer Security)
- Terror Security (Computer Security)
- National Cyber Security Services


# Brief Introduction
- Tishna is useful in Banks, Private Organisations and Ethical hacker personnel for legal auditing.
- It serves as a defense method to find as much as information possible for gaining unauthorised access and intrusion.  
- With the emergence of more advanced technology, cybercriminals have also found more ways to get into the system of many organizations. 
- Tishna software can audit, servers and web behaviour.
- Tishna can perform Scanning & Enumeration as much as possible of target.
- It’s first step to stop cyber criminals by securing your Servers and Web Application Security.
- Tishna is false positive free, when there is something it will show no matter what, if it is not, it will give blank results rather error.


# Kali Installation
- git clone https://github.com/haroonawanofficial/Tishna.git
- cd Tishna
- sudo chmod u+x *.sh
- ./Kali_Installer.sh
- Tishna will integrate as system software
- Dependencies will be handled automatically
- Third party software(s)/dependencies/modules will be handled automatically

# Developer
- Haroon Awan
- mrharoonawan@gmail.com

# Sponsor and Support via BTC
- 3BuUYgEgsRuEra4GwqNVLKnDCTjLEDfptu
