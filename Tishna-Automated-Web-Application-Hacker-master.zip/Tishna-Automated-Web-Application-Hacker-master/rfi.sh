#!/bin/bash
perl rfi.pl
