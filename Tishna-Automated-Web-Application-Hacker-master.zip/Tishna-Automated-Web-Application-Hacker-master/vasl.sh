#!/bin/bash
cd vasl
perl netblock_cname_finder.pl
