#!/bin/bash
echo -n "[+] Enter Victim: "
read Victim
perl xsslint $Victim
